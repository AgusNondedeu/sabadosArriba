package com.nicolas.ejercicio1;

public class Compra {
    String cliente;
    String autoModelo;

    public Compra(String cliente, String autoModelo){
        this.cliente = cliente;
        this.autoModelo = autoModelo;
    }

    @Override
    public String toString() {
        return "Compra{" +
                "cliente='" + cliente + '\'' +
                ", autoModelo='" + autoModelo + '\'' +
                '}';
    }
}
