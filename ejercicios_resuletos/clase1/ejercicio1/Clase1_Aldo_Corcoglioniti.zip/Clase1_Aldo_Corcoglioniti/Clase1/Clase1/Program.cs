﻿using System;

namespace Clase1
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ingrese el nombre del cliente");
            string cliente;
            string automodelo;
            cliente = Console.ReadLine();
            Console.WriteLine("Ingrese modelo de auto");
           
            automodelo = Console.ReadLine();
            Console.WriteLine("El cliente se llama: " + cliente  + " el modelo de auto es:  " + automodelo );
            Console.WriteLine("grabando........ ");
            //grabando.
        }

        
    }
}
