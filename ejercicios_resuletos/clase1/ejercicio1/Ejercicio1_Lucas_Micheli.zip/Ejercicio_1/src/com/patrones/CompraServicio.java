package com.patrones;

public class CompraServicio {
    void comprar(Compra compra){
        System.out.println("Se ha guardado la compra");
    };
}
