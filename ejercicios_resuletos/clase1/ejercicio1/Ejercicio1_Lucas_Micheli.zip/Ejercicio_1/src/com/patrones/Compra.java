package com.patrones;

public class Compra {
    String cliente;
    String autoModelo;
}
