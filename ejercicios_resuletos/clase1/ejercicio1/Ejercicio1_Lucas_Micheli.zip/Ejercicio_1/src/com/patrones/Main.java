package com.patrones;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner entradaEscaner = new Scanner (System.in);
        Compra nuevaCompra = new Compra();
        CompraServicio servicio = new CompraServicio();

        System.out.println ("Introducir nombre del cliente");
        nuevaCompra.cliente = entradaEscaner.nextLine ();

        System.out.println ("Introducir el modelo del auto");
        nuevaCompra.autoModelo = entradaEscaner.nextLine ();

        servicio.comprar(nuevaCompra);


    }
}
